package Translator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TranslatorApp extends JFrame {

    private Dictionary dictionary;

    private JTextField englishInputField;
    private JTextField spanishInputField;
    private JTextArea resultArea;

    public TranslatorApp() {
        dictionary = new Dictionary();
        setupUI();
    }

    private void setupUI() {
        setTitle("Offline Translator (English → Spanish)");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel principal
        JPanel panel = new JPanel(new GridLayout(6, 1, 10, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Campo para escribir palabra en inglés
        englishInputField = new JTextField();
        panel.add(new JLabel("Enter word in English:"));
        panel.add(englishInputField);

        // Resultado
        resultArea = new JTextArea(2, 20);
        resultArea.setEditable(false);
        panel.add(new JLabel("Translation:"));
        panel.add(resultArea);

        // Botón traducir
        JButton translateButton = new JButton("Translate");
        translateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String englishWord = englishInputField.getText().trim();
                String translation = dictionary.translate(englishWord);
                resultArea.setText(translation);
            }
        });

        // Panel para botón y agregar nueva palabra
        JPanel bottomPanel = new JPanel(new GridLayout(2, 2, 5, 5));

        // Campo en español
        spanishInputField = new JTextField();
        bottomPanel.add(new JLabel("Add Spanish translation:"));
        bottomPanel.add(spanishInputField);

        // Botón para agregar nueva palabra
        JButton addButton = new JButton("Add Word");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String english = englishInputField.getText().trim();
                String spanish = spanishInputField.getText().trim();
                if (!english.isEmpty() && !spanish.isEmpty()) {
                    dictionary.addWord(english, spanish);
                    dictionary.saveDictionary();
                    JOptionPane.showMessageDialog(null, "Word added successfully!");
                    englishInputField.setText("");
                    spanishInputField.setText("");
                }
            }
        });

        bottomPanel.add(translateButton);
        bottomPanel.add(addButton);

        add(panel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TranslatorApp());
    }
}
