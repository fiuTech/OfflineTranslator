package Translator;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class Dictionary {
    private Map<String, String> dictionary;
    private final String filePath = "dictionary.txt";

    public Dictionary() {
        dictionary = new HashMap<>();
        loadDictionary();
    }

    // Load dictionary from file
    private void loadDictionary() {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains("=")) {
                    String[] parts = line.split("=");
                    if (parts.length == 2) {
                        dictionary.put(parts[0].trim().toLowerCase(), parts[1].trim().toLowerCase());
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("No dictionary file found. A new one will be created.");
        }
    }

    // Save dictionary to file
    public void saveDictionary() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (Map.Entry<String, String> entry : dictionary.entrySet()) {
                writer.write(entry.getKey() + "=" + entry.getValue());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving dictionary: " + e.getMessage());
        }
    }

    // Translate word
    public String translate(String englishWord) {
        return dictionary.getOrDefault(englishWord.toLowerCase(), "Not found");
    }

    // Add new translation
    public void addWord(String englishWord, String spanishTranslation) {
        dictionary.put(englishWord.toLowerCase(), spanishTranslation.toLowerCase());
    }
}
