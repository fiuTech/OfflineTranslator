package Translator;


import java.io.*;
import java.util.*;

public class DictionaryLoader {

    public static Map<String, String> loadDictionary(String filename) {
        Map<String, String> dictionary = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.strip().split("=");
                if (parts.length == 2) {
                    dictionary.put(parts[0].toLowerCase(), parts[1].toLowerCase());
                }
            }
        } catch (IOException e) {
            System.out.println("No dictionary file found, starting with empty dictionary.");
        }

        return dictionary;
    }

    public static void saveWord(String filename, String english, String spanish) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
            writer.write(english + "=" + spanish);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
